//------------------------------------------------------------------------
// NAME: Mihaela Gadzhalova
// CLASS: XIb
// NUMBER: 18
// PROBLEM: #1
// FILE NAME: tail.c
// FILE PURPOSE:
// Raelisation of the system function tail



#include<stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

int read_stdin();
void reverse_string(char* str);
int check_for_errors();

int main(int argc, char **argv) {

  if(argc == 1) {
    return read_stdin();
  }
  int headers = 0;
  for(int i = 1; i < argc; i++) {

    char *filename = argv[i];
    int open_file = open(filename,O_RDONLY);
    char symbol;
    int lines = 0, max_lines = 10, bytes_count = 0;
    
    if(argv[i][0] == '-') {
      if(headers > 0) write(STDOUT_FILENO, "\n", 1);
      if(argc > 2) write(STDOUT_FILENO,"==> standard input <==\n", 23);
      read_stdin();
      headers++;
      continue;
    }

    if(open_file < 0) {

      char first = strlen("tail: cannot open \'");
      char second = strlen("\' for reading");
      char* err = malloc(first + strlen(filename) + second);

      strcat(err, "tail: cannot open \'");
      strcat(err, filename);
      strcat(err, "\' for reading");
      perror(err);
      free(err);

      continue;
    }

    ssize_t read_file = read(open_file, &symbol, 1);
    if(read_file < 0) {
      char first = strlen("tail: error reading \'");
      char second = strlen("\'");
      char* err = malloc(first + strlen(filename) + second);

      strcat(err, "tail: error reading \'");
      strcat(err, filename);
      strcat(err, "\'");
      perror(err);
      free(err);
      continue;
    }

    if(argc > 2) {
      if(headers > 0) write(STDOUT_FILENO, "\n", 1);
      write(1, "==> ", 4);
      write(1, argv[i], strlen(argv[i]));
      write(1, " <==\n", 5);
      headers++;
    }

    off_t size = lseek(open_file,0,SEEK_END);

    while(lines < max_lines) {
      if(bytes_count == size){
         lseek(open_file, -size, SEEK_END); //Ako stignem do kraq na faila predi da sme procheli 10 reda, vryshtame poitera s lseek size byta predi kraq na faila i break-vame, za da ne prebroqvame redove izvyn faila
         break;
      }
      lseek(open_file, -2, SEEK_CUR);
      read(open_file, &symbol ,1);
      bytes_count++;
      if(symbol == '\n') lines++;
    }

    if(lines < max_lines) {
      max_lines = lines + 1;
    }
    lines = 0;

    read_file = read(open_file, &symbol, 1);
    while(read_file > 0 && lines < max_lines){

     if(symbol == '\n') lines++;

     ssize_t wb = write(1 ,&symbol,1);
     int br_from_write = 0;
     while(wb != 1){
        if(wb != 0) {
         char *first = "tail: error writing \'standard output\'";
         perror(first);
         br_from_write = 1;
	 break;
        }
      wb = write(1 ,&symbol,1);
     }
     if(br_from_write == 1)break;

     read_file = read(open_file, &symbol, 1);
  }

  int close_file = close(open_file);
  if(close_file < 0) {
    char first = strlen("tail: error reading \'");
    char second = strlen("\'");
    char* err = malloc(first + strlen(filename) + second);
    
    strcat(err, "tail: error reading \'");
    strcat(err, filename);
    strcat(err, "\'");
    perror(err);
    free(err);
  }
  }
  return 0;
}

int read_stdin() {
	
    	int size = 100;
	char symbol[1];
	char *words = malloc(size * sizeof(char));
	int i = 0;
	int lines = 0;
	int normaal_state = 0;
	int check;
	int dali;
	int max_lines = 10;

	while(read(STDIN_FILENO, symbol, 1) != 0) {
		if(size == size) {
			size = size * 2;
			words = realloc(words, size * sizeof(char));
		}
		if(symbol[0] == '\n') {
			lines++;
		}
		words[i] = symbol[0];
		i++;
	}

	if(lines < 11) {
		for(int mini = 0; mini <= i; mini++) {
			symbol[0] = words[mini];
			check = write(STDOUT_FILENO, symbol, 1);
			if(check < 0) {
				perror("tail: error writing 'standart output'");
                		return 1;
			}
		}
		return 0;
	} else {
		int normal_state = lines - 10;
		int walk = 0;
		while(dali != normal_state) {
			if(words[walk] == '\n') {
				dali++;
			}
			walk++;
		}
	
		for(; walk < i; walk++) {
			symbol[0] = words[walk];
			check = write(STDOUT_FILENO, symbol, 1);
			if(check < 0) {
				perror("tail: error writing 'standart output'");
                		return 1;
			}
		}
 	}

	free(words);
	return 0;
}

